package com.gg.trex.event;

import com.gg.trex.entity.CarcassEntity;
import com.gg.trex.entity.DilophosaurusEntity;
import com.gg.trex.entity.GGDinoEntity;
import com.gg.trex.entity.RaptorEntity;
import com.gg.trex.entity.TRexEntity;
import com.gg.trex.registry.ModEntities;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.animal.Chicken;
import net.minecraft.world.entity.animal.Cow;
import net.minecraft.world.entity.animal.Pig;
import net.minecraft.world.entity.animal.Sheep;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.levelgen.Heightmap;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.living.LivingDropsEvent;

/** Mod-bus and game-bus event handlers shared by client and server. */
public final class CommonEvents {
    private CommonEvents() {}

    /** Items a wild dinosaur "eats" instead of dropping (same list as the Bedrock add-on). */
    private static final Set<String> MEAT_DROPS = Set.of(
            "beef", "cooked_beef", "leather",
            "porkchop", "cooked_porkchop",
            "mutton", "cooked_mutton",
            "chicken", "cooked_chicken", "feather");

    public static void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(ModEntities.TREX.get(), TRexEntity.createAttributes().build());
        event.put(ModEntities.RAPTOR.get(), RaptorEntity.createAttributes().build());
        event.put(ModEntities.DILOPHOSAURUS.get(), DilophosaurusEntity.createAttributes().build());
    }

    public static void registerSpawnPlacements(RegisterSpawnPlacementsEvent event) {
        event.register(ModEntities.TREX.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CommonEvents::checkDinoSpawn,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(ModEntities.RAPTOR.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CommonEvents::checkDinoSpawn,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
        event.register(ModEntities.DILOPHOSAURUS.get(), SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, CommonEvents::checkDinoSpawn,
                RegisterSpawnPlacementsEvent.Operation.REPLACE);
    }

    private static <T extends GGDinoEntity> boolean checkDinoSpawn(EntityType<T> type, ServerLevelAccessor level,
            MobSpawnType reason, BlockPos pos, RandomSource random) {
        return Animal.checkAnimalSpawnRules(type, level, reason, pos, random);
    }

    /**
     * A dinosaur killed a cow / pig / sheep / chicken: leave a carcass instead of the loot.
     * Wild dinosaurs eat the meat (no meat/leather/wool/feather drops); tamed ones keep the drops
     * (the carcass system still works for them).
     */
    public static void onLivingDrops(LivingDropsEvent event) {
        LivingEntity victim = event.getEntity();
        if (!(victim.level() instanceof ServerLevel level)) {
            return;
        }
        EntityType<CarcassEntity> carcassType = carcassFor(victim);
        if (carcassType == null || !(event.getSource().getEntity() instanceof GGDinoEntity dino)) {
            return;
        }
        CarcassEntity carcass = carcassType.create(level);
        if (carcass == null) {
            return;
        }
        carcass.moveTo(victim.getX(), victim.getY(), victim.getZ(), victim.getYRot(), 0.0F);
        carcass.setBaby(victim.isBaby());
        carcass.setKiller(dino.getUUID());
        level.addFreshEntity(carcass);
        if (!dino.isTame()) {
            event.getDrops().removeIf(drop -> isMeatDrop(drop.getItem()));
        }
        victim.discard();
    }

    private static EntityType<CarcassEntity> carcassFor(LivingEntity victim) {
        if (victim instanceof Cow) {
            return ModEntities.COW_CARCASS.get();
        }
        if (victim instanceof Pig) {
            return ModEntities.PIG_CARCASS.get();
        }
        if (victim instanceof Sheep) {
            return ModEntities.SHEEP_CARCASS.get();
        }
        if (victim instanceof Chicken) {
            return ModEntities.CHICKEN_CARCASS.get();
        }
        return null;
    }

    private static boolean isMeatDrop(ItemStack stack) {
        ResourceLocation key = BuiltInRegistries.ITEM.getKey(stack.getItem());
        if (!"minecraft".equals(key.getNamespace())) {
            return false;
        }
        String path = key.getPath();
        return MEAT_DROPS.contains(path) || path.endsWith("_wool");
    }
}
