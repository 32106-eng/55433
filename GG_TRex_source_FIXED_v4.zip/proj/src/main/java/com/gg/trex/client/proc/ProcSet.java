package com.gg.trex.client.proc;

/** The procedural (Molang-derived) animation set of one species. */
public record ProcSet(IdleFn idle, WalkFn walk, String[] lookBones, double[] lookFactors, double idleLoop,
                      String hideWhenSaddled) {

    @FunctionalInterface
    public interface IdleFn {
        void apply(Pose pose, double lifeSeconds, float weight);
    }

    @FunctionalInterface
    public interface WalkFn {
        void apply(Pose pose, double distance, double speed, float weight);
    }

    public static final ProcSet TREX = new ProcSet(TRexProc::idle, TRexProc::walk,
            TRexProc.LOOK_BONES, TRexProc.LOOK_FACTORS, TRexProc.IDLE_LOOP, null);

    public static final ProcSet RAPTOR = new ProcSet(RaptorProc::idle, RaptorProc::walk,
            RaptorProc.LOOK_BONES, RaptorProc.LOOK_FACTORS, RaptorProc.IDLE_LOOP, "crest_mid");

    public static final ProcSet DILOPHOSAURUS = new ProcSet(DiloProc::idle, DiloProc::walk,
            DiloProc.LOOK_BONES, DiloProc.LOOK_FACTORS, DiloProc.IDLE_LOOP, null);
}
