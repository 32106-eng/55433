package com.gg.trex.client.renderer;

import com.gg.trex.client.model.DinoModel;
import com.mojang.blaze3d.vertex.PoseStack;
import com.gg.trex.entity.GGDinoEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import com.mojang.math.Axis;
import software.bernie.geckolib.renderer.GeoEntityRenderer;
import software.bernie.geckolib.renderer.layer.AutoGlowingGeoLayer;

/** Dinosaur renderer: GeckoLib model + emissive glowing eyes (textures/entity/NAME_glowmask.png). */
public class DinoRenderer<T extends GGDinoEntity> extends GeoEntityRenderer<T> {
    public DinoRenderer(EntityRendererProvider.Context context, DinoModel<T> model, float shadowSize) {
        super(context, model);
        this.shadowRadius = shadowSize;
        this.addRenderLayer(new AutoGlowingGeoLayer<>(this));
    }

    /** Keep horizontal dinosaur models from inheriting living-entity flip/roll transforms. */
    @Override
    protected void applyRotations(T entity, PoseStack poseStack, float ageInTicks,
                                  float rotationYaw, float partialTick, float scale) {
        // GeoEntityRenderer normally rolls dead, sleeping, upside-down and spin-attacking mobs.
        // Those transforms are correct for upright humanoids but turn this horizontal model into a
        // vertical/floating-looking creature. Dinosaurs only need to turn around the Y axis.
        poseStack.mulPose(Axis.YP.rotationDegrees(180.0F - rotationYaw));
    }
}
