package com.gg.trex.client.proc;

import software.bernie.geckolib.animation.AnimationProcessor;
import software.bernie.geckolib.cache.object.GeoBone;

/**
 * Applies additive bone offsets on top of the current GeckoLib pose.
 * Rotations / positions use the same numbers as the Bedrock add-on animations
 * (degrees for rotation, model pixels for position); the sign conventions of GeckoLib are handled here.
 */
public final class Pose {
    private final AnimationProcessor<?> processor;

    public Pose(AnimationProcessor<?> processor) {
        this.processor = processor;
    }

    /** Add a rotation (degrees, Bedrock convention) scaled by weight. */
    public void rot(String bone, double xDeg, double yDeg, double zDeg, float weight) {
        GeoBone b = processor.getBone(bone);
        if (b == null || weight <= 0.0F) {
            return;
        }
        b.updateRotation(
                b.getRotX() + (float) Math.toRadians(-xDeg) * weight,
                b.getRotY() + (float) Math.toRadians(-yDeg) * weight,
                b.getRotZ() + (float) Math.toRadians(zDeg) * weight);
    }

    /** Add a position offset (model pixels, Bedrock convention) scaled by weight. */
    public void pos(String bone, double x, double y, double z, float weight) {
        GeoBone b = processor.getBone(bone);
        if (b == null || weight <= 0.0F) {
            return;
        }
        b.updatePosition(
                b.getPosX() + (float) x * weight,
                b.getPosY() + (float) y * weight,
                b.getPosZ() + (float) z * weight);
    }

    /** Add raw rotation in radians (already in GeckoLib convention), e.g. for head tracking. */
    public void addRotRadians(String bone, float xRad, float yRad, float zRad, float weight) {
        GeoBone b = processor.getBone(bone);
        if (b == null || weight <= 0.0F) {
            return;
        }
        b.updateRotation(b.getRotX() + xRad * weight, b.getRotY() + yRad * weight, b.getRotZ() + zRad * weight);
    }

    public void setHidden(String bone, boolean hidden) {
        GeoBone b = processor.getBone(bone);
        if (b != null) {
            b.setHidden(hidden);
        }
    }
}
