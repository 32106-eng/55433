package com.gg.trex.client;

import net.neoforged.neoforge.common.ModConfigSpec;

/** Client side options (config/ggtrex-client.toml, also editable from the Mods screen). */
public final class ClientConfig {
    private ClientConfig() {}

    private static final ModConfigSpec.Builder BUILDER = new ModConfigSpec.Builder();

    public static final ModConfigSpec.DoubleValue SHAKE_STRENGTH = BUILDER
            .comment("Camera shake near stomping / roaring dinosaurs. 0 = off, 1 = default, 2 = double.")
            .defineInRange("cameraShakeStrength", 1.0, 0.0, 2.0);

    public static final ModConfigSpec SPEC = BUILDER.build();

    public static double shakeStrength() {
        try {
            return SHAKE_STRENGTH.get();
        } catch (IllegalStateException notLoadedYet) {
            return 1.0;
        }
    }
}
