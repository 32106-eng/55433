package com.gg.trex.client;

import com.gg.trex.GGTrex;
import com.gg.trex.client.model.DinoModel;
import com.gg.trex.client.model.StaticGeoModel;
import com.gg.trex.client.proc.ProcSet;
import com.gg.trex.client.renderer.CarcassRenderer;
import com.gg.trex.client.renderer.DinoRenderer;
import com.gg.trex.entity.DilophosaurusEntity;
import com.gg.trex.entity.RaptorEntity;
import com.gg.trex.entity.TRexEntity;
import com.gg.trex.entity.VenomSpitEntity;
import com.gg.trex.registry.ModEntities;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
import net.neoforged.neoforge.common.NeoForge;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/** Client entry point: renderers, camera shake, config screen. */
@Mod(value = GGTrex.MODID, dist = Dist.CLIENT)
public class GGTrexClient {
    public GGTrexClient(IEventBus modBus, ModContainer container) {
        modBus.addListener(GGTrexClient::registerRenderers);
        NeoForge.EVENT_BUS.addListener(ShakeManager::onClientTick);
        NeoForge.EVENT_BUS.addListener(ShakeManager::onCameraAngles);
        container.registerConfig(ModConfig.Type.CLIENT, ClientConfig.SPEC);
        container.registerExtensionPoint(IConfigScreenFactory.class, ConfigurationScreen::new);
    }

    private static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerEntityRenderer(ModEntities.TREX.get(),
                ctx -> new DinoRenderer<TRexEntity>(ctx, new DinoModel<TRexEntity>("trex", ProcSet.TREX), 1.9F));
        event.registerEntityRenderer(ModEntities.RAPTOR.get(),
                ctx -> new DinoRenderer<RaptorEntity>(ctx, new DinoModel<RaptorEntity>("raptor", ProcSet.RAPTOR), 0.6F));
        event.registerEntityRenderer(ModEntities.DILOPHOSAURUS.get(),
                ctx -> new DinoRenderer<DilophosaurusEntity>(ctx,
                        new DinoModel<DilophosaurusEntity>("dilophosaurus", ProcSet.DILOPHOSAURUS), 0.9F));
        event.registerEntityRenderer(ModEntities.VENOM_SPIT.get(),
                ctx -> new GeoEntityRenderer<VenomSpitEntity>(ctx,
                        new StaticGeoModel<VenomSpitEntity>("venom_spit", "textures/entity/venom_spit.png")));
        event.registerEntityRenderer(ModEntities.COW_CARCASS.get(), ctx -> new CarcassRenderer(ctx, "cow_carcass"));
        event.registerEntityRenderer(ModEntities.PIG_CARCASS.get(), ctx -> new CarcassRenderer(ctx, "pig_carcass"));
        event.registerEntityRenderer(ModEntities.SHEEP_CARCASS.get(), ctx -> new CarcassRenderer(ctx, "sheep_carcass"));
        event.registerEntityRenderer(ModEntities.CHICKEN_CARCASS.get(), ctx -> new CarcassRenderer(ctx, "chicken_carcass"));
    }
}
