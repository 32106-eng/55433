package com.gg.trex.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;

public class TRexEntity extends GGDinoEntity {
    public TRexEntity(EntityType<? extends TRexEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 120.0)
                .add(Attributes.ATTACK_DAMAGE, 8.0)
                .add(Attributes.MOVEMENT_SPEED, 0.30)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.8)
                .add(Attributes.STEP_HEIGHT, 1.0625)
                .add(Attributes.JUMP_STRENGTH, 0.85);
    }

    @Override protected int experienceReward() { return 40; }
    @Override protected double tameChance() { return 0.34; }
    @Override protected float healRaw() { return 6.0F; }
    @Override protected float healCooked() { return 12.0F; }
    /** Seat position (blocks above / behind the entity origin). Tweak here if the rider sits too high or low. */
    @Override protected float seatY() { return 4.5F; }
    @Override protected float seatZ() { return -0.2F; }
    @Override protected double strideBlocks() { return 4.2857; }
    @Override protected double meleeSpeed() { return 1.0; }
    @Override protected double strollSpeed() { return 0.6; }
    @Override protected double temptSpeed() { return 1.1; }
    @Override protected double playerAggroRange() { return 24.0; }
    @Override protected double preyAggroRange() { return 20.0; }
    @Override public double carcassWalkSpeed() { return 0.26; }
    @Override public double eatDistance() { return 4.3; }
    @Override public float turnSpeed() { return 7.0F; }

    @Override protected SoundEvent stepSound() { return SoundEvents.RAVAGER_STEP; }
    @Override protected SoundEvent ambientSound() { return SoundEvents.RAVAGER_AMBIENT; }
    @Override protected SoundEvent hurtSound() { return SoundEvents.RAVAGER_HURT; }
    @Override protected SoundEvent deathSound() { return SoundEvents.RAVAGER_DEATH; }
    @Override protected float pitchMin() { return 0.55F; }
    @Override protected float pitchMax() { return 0.75F; }

    @Override
    protected SoundEvent keyframeSound(String key) {
        return switch (key) {
            case "step" -> SoundEvents.RAVAGER_STEP;
            case "roar" -> SoundEvents.RAVAGER_ROAR;
            case "eat" -> SoundEvents.FOX_EAT;
            default -> null;
        };
    }

    @Override
    protected float soundPitchFor(String key) {
        return switch (key) {
            case "step" -> 0.7F;
            case "roar" -> 0.6F;
            case "eat" -> 0.75F;
            default -> 1.0F;
        };
    }

    @Override protected int footstepShake() { return 2; }

    @Override
    protected void tryIdleGesture() {
        float r = this.random.nextFloat();
        if (r < 0.0009F) {
            this.gesture("roar", 70);
            this.scheduleEffect(9, EVENT_ROAR);
        } else if (r < 0.0024F) {
            this.gesture("sniff", 60);
        } else if (r < 0.0045F) {
            this.gesture("look_around", 70);
        } else if (r < 0.0057F) {
            this.gesture("stomp", 45);
            this.scheduleEffect(12, EVENT_STOMP_HEAVY);
            this.scheduleEffect(30, EVENT_STOMP_HEAVY);
        }
    }

    @Override
    protected void registerActions(AnimationController<GGDinoEntity> action) {
        action.triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"))
                .triggerableAnim("roar", RawAnimation.begin().thenPlay("roar"))
                .triggerableAnim("sniff", RawAnimation.begin().thenPlay("sniff"))
                .triggerableAnim("look_around", RawAnimation.begin().thenPlay("look_around"))
                .triggerableAnim("stomp", RawAnimation.begin().thenPlay("stomp"))
                .triggerableAnim("eat_out", RawAnimation.begin().thenPlay("eat_out"));
    }
}
