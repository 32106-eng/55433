package com.gg.trex.entity;

import com.gg.trex.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.util.GeckoLibUtil;

/** Poisonous spit fired by the Dilophosaurus. */
public class VenomSpitEntity extends ThrowableProjectile implements GeoEntity {
    private final AnimatableInstanceCache geoCache = GeckoLibUtil.createInstanceCache(this);

    public VenomSpitEntity(EntityType<? extends VenomSpitEntity> type, Level level) {
        super(type, level);
    }

    public VenomSpitEntity(Level level, LivingEntity shooter) {
        super(ModEntities.VENOM_SPIT.get(), shooter, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) {
            this.level().addParticle(ParticleTypes.ITEM_SLIME, this.getX(), this.getY(), this.getZ(), 0.0, 0.0, 0.0);
        } else if (this.tickCount > 80 || this.isInWater()) {
            this.discard();
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        Entity target = result.getEntity();
        Entity owner = this.getOwner();
        if (target == owner || target instanceof GGDinoEntity) {
            return;
        }
        Entity source = owner == null ? this : owner;
        target.hurt(this.damageSources().thrown(this, source), 2.0F + this.random.nextInt(2));
        if (target instanceof LivingEntity living) {
            int duration = switch (this.level().getDifficulty()) {
                case EASY -> 100;
                case HARD -> 220;
                default -> 160;
            };
            living.addEffect(new MobEffectInstance(MobEffects.POISON, duration, 0), source);
        }
        this.playSound(SoundEvents.ARROW_HIT, 0.6F, 1.2F);
    }

    @Override
    protected void onHit(HitResult result) {
        super.onHit(result);
        if (!this.level().isClientSide) {
            this.level().broadcastEntityEvent(this, (byte) 3);
            this.discard();
        }
    }

    @Override
    public void handleEntityEvent(byte id) {
        if (id == 3) {
            for (int i = 0; i < 8; ++i) {
                this.level().addParticle(ParticleTypes.ITEM_SLIME, this.getX(), this.getY(), this.getZ(),
                        (this.random.nextDouble() - 0.5) * 0.15, 0.05, (this.random.nextDouble() - 0.5) * 0.15);
            }
        } else {
            super.handleEntityEvent(id);
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.geoCache;
    }
}
