package com.gg.trex.entity;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.monster.RangedAttackMob;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;

public class DilophosaurusEntity extends GGDinoEntity implements RangedAttackMob {
    public DilophosaurusEntity(EntityType<? extends DilophosaurusEntity> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 60.0)
                .add(Attributes.ATTACK_DAMAGE, 3.0)
                .add(Attributes.MOVEMENT_SPEED, 0.27)
                .add(Attributes.FOLLOW_RANGE, 24.0)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.4)
                .add(Attributes.STEP_HEIGHT, 1.0625)
                .add(Attributes.JUMP_STRENGTH, 0.8);
    }

    @Override protected int experienceReward() { return 24; }
    @Override protected double tameChance() { return 0.25; }
    @Override protected float healRaw() { return 6.0F; }
    @Override protected float healCooked() { return 12.0F; }
    @Override protected float seatY() { return 1.8F; }
    @Override protected float seatZ() { return 0.1F; }
    @Override protected double strideBlocks() { return 3.6; }
    @Override protected double meleeSpeed() { return 1.0; }
    @Override protected double strollSpeed() { return 0.5; }
    @Override protected double temptSpeed() { return 1.0; }
    @Override protected double playerAggroRange() { return 18.0; }
    @Override protected double preyAggroRange() { return 18.0; }
    @Override public double carcassWalkSpeed() { return 0.27; }
    @Override public double eatDistance() { return 2.4; }
    @Override public float turnSpeed() { return 8.0F; }
    @Override protected boolean alertsSameType() { return false; }

    @Override protected SoundEvent stepSound() { return SoundEvents.LLAMA_STEP; }
    @Override protected SoundEvent ambientSound() { return SoundEvents.CAT_HISS; }
    @Override protected SoundEvent hurtSound() { return SoundEvents.HOGLIN_HURT; }
    @Override protected SoundEvent deathSound() { return SoundEvents.HOGLIN_DEATH; }
    @Override protected float pitchMin() { return 0.6F; }
    @Override protected float pitchMax() { return 0.85F; }

    @Override
    protected SoundEvent keyframeSound(String key) {
        return switch (key) {
            case "step" -> SoundEvents.LLAMA_STEP;
            case "call" -> SoundEvents.CAT_HISS;
            case "eat" -> SoundEvents.FOX_EAT;
            default -> null;
        };
    }

    @Override protected int footstepShake() { return 1; }

    @Override
    protected void addCombatGoals() {
        this.goalSelector.addGoal(2, new RangedAttackGoal(this, 1.0, 30, 14.0F));
        super.addCombatGoals();
    }

    @Override
    public void performRangedAttack(LivingEntity target, float velocity) {
        VenomSpitEntity spit = new VenomSpitEntity(this.level(), this);
        Vec3 look = this.getLookAngle();
        spit.setPos(this.getX() + look.x * 1.2, this.getEyeY() - 0.15, this.getZ() + look.z * 1.2);
        double dx = target.getX() - spit.getX();
        double dy = target.getY(0.3333333333333333) - spit.getY();
        double dz = target.getZ() - spit.getZ();
        double arc = Math.sqrt(dx * dx + dz * dz) * 0.2;
        spit.shoot(dx, dy + arc, dz, 1.6F, 5.0F);
        this.level().addFreshEntity(spit);
        this.playSound(SoundEvents.FOX_SPIT, 1.0F, 0.8F + this.random.nextFloat() * 0.3F);
        this.triggerAnim("action", "spit");
    }

    @Override
    protected void tryIdleGesture() {
        if (this.random.nextFloat() < 0.0015F) {
            this.gesture("frill_flare", 80);
        }
    }

    @Override
    protected void registerActions(AnimationController<GGDinoEntity> action) {
        action.triggerableAnim("attack", RawAnimation.begin().thenPlay("attack"))
                .triggerableAnim("spit", RawAnimation.begin().thenPlay("spit"))
                .triggerableAnim("frill_flare", RawAnimation.begin().thenPlay("frill_flare"))
                .triggerableAnim("eat_out", RawAnimation.begin().thenPlay("eat_out"));
    }
}
