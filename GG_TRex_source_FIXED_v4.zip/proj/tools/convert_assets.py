#!/usr/bin/env python3
"""
Convert the GG T-Rex Bedrock add-on resource pack (GG_TRex_RP) into assets for the NeoForge mod.

  * geo models      -> assets/ggtrex/geo/*.geo.json          (bones re-ordered parents-first)
  * animations      -> assets/ggtrex/animations/*.json        (Molang baked into plain keyframes)
  * procedural idle / walk / flies (Molang driven)  -> generated Java in client/proc/*Proc.java
  * textures        -> assets/ggtrex/textures/...             (+ *_glowmask.png for glowing eyes)

Usage:  python3 tools/convert_assets.py <path-to-GG_TRex_RP> <project-root>
Needs:  Pillow, numpy (only for the glow masks)
"""
import json
import math
import os
import re
import shutil
import sys

RP = sys.argv[1]
ROOT = sys.argv[2]
ASSETS = os.path.join(ROOT, "src/main/resources/assets/ggtrex")
JAVA = os.path.join(ROOT, "src/main/java/com/gg/trex/client/proc")

SPECIES = {
    # name: (animation file, animation prefix, attack length in seconds, idle loop length or 0)
    "trex": ("trex.animation.json", "gg_trex", 0.55, 0.0),
    "raptor": ("raptor.animation.json", "gg_raptor", 0.45, 3.2),
    "dilophosaurus": ("dilophosaurus.animation.json", "gg_dilophosaurus", 0.50, 3.6),
}
JAVA_CLASS = {"trex": "TRexProc", "raptor": "RaptorProc", "dilophosaurus": "DiloProc"}
DROP = ("idle", "walk", "look_at_target", "step_loop", "flies")


# ----------------------------------------------------------------------------------------------
# Molang helpers
# ----------------------------------------------------------------------------------------------
def to_python(expr):
    s = str(expr)
    s = s.replace("math.sin(", "_sin(").replace("math.cos(", "_cos(").replace("math.clamp(", "_clamp(")
    s = re.sub(r"query\.anim_time|query\.life_time", "T", s)
    s = s.replace("variable.attack_time", "AT")
    if re.search(r"math\.|query\.|variable\.", s):
        raise ValueError("unsupported Molang token in: " + str(expr))
    return s


def _sin(d):
    return math.sin(math.radians(d))


def _cos(d):
    return math.cos(math.radians(d))


def _clamp(v, lo, hi):
    return max(lo, min(hi, v))


def mo_eval(expr, T=0.0, AT=0.0):
    if isinstance(expr, (int, float)):
        return float(expr)
    return float(eval(to_python(expr), {"_sin": _sin, "_cos": _cos, "_clamp": _clamp, "T": T, "AT": AT}))


def has_molang(v):
    return bool(re.search(r"math\.|query\.|variable\.", json.dumps(v)))


def to_java(expr):
    """Translate one Molang component to a Java double expression."""
    if isinstance(expr, (int, float)):
        return repr(float(expr))
    s = str(expr)
    s = s.replace("math.sin(", "M.sin(").replace("math.cos(", "M.cos(").replace("math.clamp(", "M.clamp(")
    s = re.sub(r"query\.life_time|query\.anim_time", "t", s)
    s = s.replace("query.modified_distance_moved", "dist").replace("query.modified_move_speed", "spd")
    if re.search(r"math\.|query\.|variable\.", s):
        raise ValueError("unsupported Molang token in: " + str(expr))
    return s


def r4(x):
    x = round(x, 4)
    return 0.0 if x == 0 else x


def bake_vec3(vec, times, length, attack=False):
    """vec = 3 components (numbers / Molang strings). Returns {time: [x,y,z]} sampled keyframes."""
    out = {}
    for t in times:
        if attack:
            at = min(1.0, t / length)
            out["%.3f" % t] = [r4(mo_eval(c, AT=at)) for c in vec]
        else:
            out["%.3f" % t] = [r4(mo_eval(c, T=t)) for c in vec]
    return out


# ----------------------------------------------------------------------------------------------
# geometry
# ----------------------------------------------------------------------------------------------
def convert_geo(src_name, dst_name):
    d = json.load(open(os.path.join(RP, "models/entity", src_name)))
    geos = d["minecraft:geometry"]
    for g in geos:
        bones = g["bones"]
        by_name = {b["name"]: b for b in bones}
        ordered, seen = [], set()

        def visit(b):
            if b["name"] in seen:
                return
            p = b.get("parent")
            if p and p in by_name:
                visit(by_name[p])
            seen.add(b["name"])
            ordered.append(b)

        for b in bones:
            visit(b)
        g["bones"] = ordered
    with open(os.path.join(ASSETS, "geo", dst_name), "w") as f:
        json.dump(d, f, separators=(",", ":"))
    return {b["name"] for g in geos for b in g["bones"]}


# ----------------------------------------------------------------------------------------------
# animations
# ----------------------------------------------------------------------------------------------
def convert_animations(species, fname, prefix, attack_len):
    d = json.load(open(os.path.join(RP, "animations", fname)))
    out = {"format_version": d.get("format_version", "1.8.0"), "animations": {}}
    for full, a in d["animations"].items():
        short = full.split(".")[-1]
        if short in DROP:
            continue
        a = json.loads(json.dumps(a))
        if short == "attack":
            a["loop"] = False
            a["animation_length"] = attack_len
            times = [i / 40.0 for i in range(int(round(attack_len * 40)) + 1)]
            for bone, chans in a["bones"].items():
                for ch, val in list(chans.items()):
                    if has_molang(val):
                        chans[ch] = bake_vec3(val, times, attack_len, attack=True)
        else:
            length = a.get("animation_length")
            for bone, chans in a.get("bones", {}).items():
                for ch, val in list(chans.items()):
                    if has_molang(val):
                        if isinstance(val, list):
                            L = length or 1.0
                            n = int(round(L / 0.05))
                            times = [i * 0.05 for i in range(n + 1)]
                            if abs(times[-1] - L) > 1e-6:
                                times.append(L)
                            chans[ch] = bake_vec3(val, times, L)
                        else:
                            raise ValueError("Molang inside keyframed channel not handled: %s %s" % (full, bone))
            if "animation_length" not in a and a.get("loop"):
                a["animation_length"] = 1.0  # constant pose: give it a real length so GeckoLib can loop it
        out["animations"][short] = a
    assert not has_molang(out), "Molang left over in " + fname
    with open(os.path.join(ASSETS, "animations", species + ".animation.json"), "w") as f:
        json.dump(out, f, separators=(",", ":"))
    return d


# ----------------------------------------------------------------------------------------------
# procedural Java
# ----------------------------------------------------------------------------------------------
def emit_channel(lines, bone, chan, vec, indent="        "):
    if all(isinstance(c, (int, float)) and c == 0 for c in vec):
        return
    x, y, z = (to_java(c) for c in vec)
    lines.append('%sp.%s("%s", %s, %s, %s, w);' % (indent, "rot" if chan == "rotation" else "pos", bone, x, y, z))


def gen_java(species, anim_data, prefix, geo_bones, idle_loop):
    cls = JAVA_CLASS[species]
    anims = anim_data["animations"]
    idle = anims["animation.%s.idle" % prefix]
    walk = anims["animation.%s.walk" % prefix]
    look = anims["animation.%s.look_at_target" % prefix]

    k = None
    for m in re.finditer(r"modified_distance_moved\s*\*\s*\(?([0-9.]+)", json.dumps(walk)):
        k = float(m.group(1))
    stride = 180.0 / k

    look_bones, look_factors = [], []
    for bone, chans in look["bones"].items():
        f = re.search(r"\)\s*\*\s*([0-9.]+)", str(chans["rotation"][0])).group(1)
        look_bones.append(bone)
        look_factors.append(f)

    used = set(look_bones)
    body = []
    for fn, anim, args in (("idle", idle, "Pose p, double t, float w"), ("walk", walk, "Pose p, double dist, double spd, float w")):
        body.append("    public static void %s(%s) {" % (fn, args))
        for bone, chans in anim["bones"].items():
            used.add(bone)
            for ch in ("rotation", "position"):
                if ch in chans:
                    emit_channel(body, bone, ch, chans[ch])
        body.append("    }")
        body.append("")
    missing = sorted(b for b in used if b not in geo_bones)
    if missing:
        print("WARNING: %s procedural code references missing bones: %s" % (species, missing))

    src = """// GENERATED by tools/convert_assets.py from the Bedrock add-on animations - do not edit by hand.
package com.gg.trex.client.proc;

public final class %(cls)s {
    private %(cls)s() {}

    /** Idle animation loops every this many seconds (0 = never wraps). */
    public static final double IDLE_LOOP = %(idle_loop)s;
    /** Blocks travelled per footstep (half of one walk cycle). */
    public static final double STRIDE = %(stride).4f;
    public static final String[] LOOK_BONES = {%(look_bones)s};
    public static final double[] LOOK_FACTORS = {%(look_factors)s};

%(body)s}
""" % dict(
        cls=cls,
        idle_loop=repr(float(idle_loop)),
        stride=stride,
        look_bones=", ".join('"%s"' % b for b in look_bones),
        look_factors=", ".join(look_factors),
        body="\n".join(body),
    )
    with open(os.path.join(JAVA, cls + ".java"), "w") as f:
        f.write(src)


def gen_flies_java(geo_bones):
    d = json.load(open(os.path.join(RP, "animations/carcass.animation.json")))
    flies = d["animations"]["animation.gg_carcass.flies"]
    body = ["    public static void flies(Pose p, double t) {", "        float w = 1.0F;"]
    for bone, chans in flies["bones"].items():
        if bone not in geo_bones:
            print("WARNING: carcass bone missing:", bone)
        for ch in ("rotation", "position"):
            if ch in chans:
                emit_channel(body, bone, ch, chans[ch])
    body.append("    }")
    src = """// GENERATED by tools/convert_assets.py - do not edit by hand.
package com.gg.trex.client.proc;

public final class CarcassProc {
    private CarcassProc() {}

%s
}
""" % "\n".join(body)
    with open(os.path.join(JAVA, "CarcassProc.java"), "w") as f:
        f.write(src)


# ----------------------------------------------------------------------------------------------
# textures + glow masks
# ----------------------------------------------------------------------------------------------
def glow_masks():
    from PIL import Image
    import numpy as np

    def mask(name, rects, test):
        im = Image.open(os.path.join(RP, "textures/entity", name + ".png")).convert("RGBA")
        a = np.array(im)
        out = np.zeros_like(a)
        n = 0
        for (x0, y0, x1, y1) in rects:
            for y in range(y0, y1 + 1):
                for x in range(x0, x1 + 1):
                    r, g, b, al = (int(v) for v in a[y, x])
                    if al > 200 and test(r, g, b):
                        out[y, x] = a[y, x]
                        n += 1
        Image.fromarray(out).save(os.path.join(ASSETS, "textures/entity", name + "_glowmask.png"))
        print("glow mask %s: %d pixels" % (name, n))

    orange = lambda r, g, b: r > 170 and 70 < g < 215 and b < 95 and r - b > 110
    yellow = lambda r, g, b: r > 225 and g > 175
    mask("trex", [(227, 382, 231, 386), (225, 344, 229, 348), (209, 75, 213, 79), (260, 325, 264, 329)], orange)
    mask("raptor", [(59, 70, 72, 82), (73, 54, 86, 66)], yellow)
    mask("dilophosaurus", [(73, 95, 77, 100), (80, 41, 84, 46)], orange)


def main():
    for sub in ("geo", "animations", "textures/entity/carcass", "textures/item"):
        os.makedirs(os.path.join(ASSETS, sub), exist_ok=True)
    os.makedirs(JAVA, exist_ok=True)

    geo_bones = {}
    for sp in SPECIES:
        geo_bones[sp] = convert_geo(sp + ".geo.json", sp + ".geo.json")
    for sp in ("venom_spit", "cow_carcass", "pig_carcass", "sheep_carcass", "chicken_carcass"):
        geo_bones[sp] = convert_geo(sp + ".geo.json", sp + ".geo.json")

    for sp, (fname, prefix, attack_len, idle_loop) in SPECIES.items():
        data = convert_animations(sp, fname, prefix, attack_len)
        gen_java(sp, data, prefix, geo_bones[sp], idle_loop)
    gen_flies_java(geo_bones["cow_carcass"])

    for n in ("trex", "raptor", "dilophosaurus", "venom_spit"):
        shutil.copy(os.path.join(RP, "textures/entity", n + ".png"), os.path.join(ASSETS, "textures/entity", n + ".png"))
    for n in os.listdir(os.path.join(RP, "textures/entity/carcass")):
        shutil.copy(os.path.join(RP, "textures/entity/carcass", n), os.path.join(ASSETS, "textures/entity/carcass", n))
    shutil.copy(os.path.join(RP, "textures/items/rex_saddle.png"), os.path.join(ASSETS, "textures/item/rex_saddle.png"))
    glow_masks()
    print("done")


if __name__ == "__main__":
    main()
